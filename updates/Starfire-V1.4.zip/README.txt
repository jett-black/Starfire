STARFIRE 1.4
One window for The Hidden Ones: the Starfire Lite translation overlay, the game and UU Booster - one at a time or all at once.
Same red / purple supernova look as the Starfire Lite launcher.

START
  Double-click "Starfire.exe". (Or right-click StarfireHub.ps1 > Run with PowerShell.)
  Windows' Chinese text recognition (OCR) is checked first. If it is missing, Starfire installs it (Windows asks for
  permission, a small progress window opens). Starfire does not continue without it, because the translator needs it.

IN THE WINDOW
  STARFIRE LITE      Starfire Lite 2.7 is included. INSTALL / UPDATE puts it in %LOCALAPPDATA%\StarfireLite\app (a running
                     copy is closed and started again); START LITE starts it (and installs it first if needed).
                     Tick "Desktop shortcut for Starfire Lite" before installing if you want one.
  THE HIDDEN ONES    BROWSE to the game or its launcher .exe (for example YiRenZhiXia.exe). LAUNCH GAME starts it.
  UU BOOSTER         BROWSE to UU Booster's .exe (a .lnk shortcut works too). OPEN UU starts it.
                     On first start Starfire looks for both in the list of installed programs and fills them in if found.
  LAUNCH ALL         Starts the ticked ones in this order: UU Booster, then waits (default 6 s, so you can start the
                     acceleration for the game in UU), then the game, then Starfire Lite.
  Paths and choices are remembered in %LOCALAPPDATA%\Starfire\starfire-hub.json.

NOTES
  * UU Booster usually asks for administrator permission when it starts - that is UU, not Starfire.
  * Starfire only starts programs; it does not change the game, UU Booster or any of their files.

WHAT'S NEW IN 1.1
  * The OCR check is stricter and repeated: Starfire needs the Simplified Chinese pack (zh-Hans / zh-CN) - a Traditional
    Chinese pack no longer counts. It is checked when Starfire opens AND again before every button (Install, Start Lite,
    Launch Game, Open UU, Launch All). If it is missing, Starfire offers to install it; without it, nothing is started.
  * The header shows the real OCR state (green "installed" / red "MISSING") instead of a fixed "ready".
  * After removing or adding the OCR pack, Windows sometimes needs one restart before the change counts - until then the
    pack still works. Starfire mentions this when an install does not take effect.

WHAT'S NEW IN 1.2
  * Live updates. When Starfire opens it checks github.com/jett-black/Starfire for a newer version. If a newer version
    is there, the top right shows "Update available: v1.2 -> v1.3" and an UPDATE button. UPDATE shows what is new,
    downloads it, keeps a backup of the current files (%LOCALAPPDATA%\Starfire\backup-<version>), replaces the files next
    to Starfire.exe and restarts Starfire. CHECK AGAIN checks once more. A broken or incomplete download changes nothing.
  * Starfire Lite is updated together with Starfire (it is part of the download; INSTALL / UPDATE or START LITE puts the
    new Lite in place).

WHAT'S NEW IN 1.3
  * DESKTOP SHORTCUT button (bottom row) creates a "Starfire" shortcut on the desktop that opens this Starfire.exe. It keeps
    working after live updates, because updates replace the files in the same folder. The button shows
    "SHORTCUT ON DESKTOP" once it exists; pressing it again simply recreates it.

WHAT'S NEW IN 1.4
  * The live updater now reads the update file in the repo (updates/latest.json) instead of GitHub Releases, so new
    versions can be published straight to the repo.
