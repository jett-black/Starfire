﻿# Starfire - hub for The Hidden Ones: installs / starts Starfire Lite, starts the game and UU Booster, or all three at once
param([string]$LiteVersion = '2.7', [string]$HubVersion = '1.4', [string]$ExePath = '')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$src      = $PSScriptRoot
$hubDir   = Join-Path $env:LOCALAPPDATA 'Starfire'
$cfgPath  = Join-Path $hubDir 'starfire-hub.json'
$liteData = Join-Path $env:LOCALAPPDATA 'StarfireLite'
$appDir   = Join-Path $liteData 'app'
$verFile  = Join-Path $appDir 'version.txt'
$liteFiles = @('StarfireLite.ps1', 'starfire-lite-dict.tsv', 'glossary.csv', 'starfire.ico', 'README.txt', 'Install-OcrPack.ps1', 'StarfireLiteSetup.ps1')
New-Item -ItemType Directory -Force -Path $hubDir | Out-Null

# ---------- settings (paths remembered between runs) ----------
$cfg = [ordered]@{ gamePath = ''; uuPath = ''; uuDelay = 6; startLite = $true; startUU = $true; startGame = $true }
try {
    if (Test-Path $cfgPath) {
        $j = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($k in @($cfg.Keys)) { if ($null -ne $j.$k) { $cfg[$k] = $j.$k } }
    }
} catch {}
function Save-Cfg { try { ($cfg | ConvertTo-Json) | Set-Content -Path $cfgPath -Encoding UTF8 } catch {} }

# first run: try to find UU Booster and the game by themselves
function Find-Installed([string[]]$patterns, [string[]]$exeNames) {
    $roots = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall', 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')
    foreach ($r in $roots) {
        try {
            foreach ($k in Get-ChildItem $r -ErrorAction SilentlyContinue) {
                $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
                $dn = [string]$p.DisplayName
                $hit = $false; foreach ($pt in $patterns) { if ($dn -like $pt) { $hit = $true } }
                if (-not $hit) { continue }
                $dirs = @()
                if ($p.InstallLocation) { $dirs += [string]$p.InstallLocation }
                if ($p.DisplayIcon) { $dirs += (Split-Path ([string]$p.DisplayIcon).Split(',')[0].Trim('"')) }
                foreach ($dd in $dirs) { foreach ($en in $exeNames) { $c = Join-Path $dd $en; if (Test-Path $c) { return $c } } }
            }
        } catch {}
    }
    return ''
}
if (-not $cfg.uuPath) { $cfg.uuPath = Find-Installed @('*UU*', '*网易UU*') @('uu.exe', 'UU.exe', 'uuplayer.exe', 'UUBooster.exe') }
if (-not $cfg.gamePath) { $cfg.gamePath = Find-Installed @('*异人之下*', '*Hidden Ones*', '*YiRenZhiXia*') @('YiRenZhiXia.exe', 'launcher.exe', 'Launcher.exe') }

function Test-ChineseOcr {
    try {
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        foreach ($l in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) { $lt = [string]$l.LanguageTag; if ($lt -eq 'zh-Hans' -or $lt -like 'zh-Hans-*' -or $lt -eq 'zh-CN') { return $true } }
    } catch {}
    return $false
}
function Get-LiteProcs {
    try { @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*StarfireLite.ps1*' -or $_.CommandLine -like '*StarfireLiteWD*' }) } catch { @() }
}
function Install-Ocr {
    $sp = Join-Path $src 'Install-OcrPack.ps1'
    try { $null = Start-Process powershell.exe -Verb RunAs -Wait -PassThru -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$sp`"", '-Elevated', '-App', '"Starfire"') } catch {}
    return (Test-ChineseOcr)
}

# ---------- Chinese text recognition is required ----------
# (checked at start AND again before every action: nothing goes ahead without it)
function Ensure-Ocr {
    if (Test-ChineseOcr) { return $true }
    while ($true) {
        $q = "Starfire needs Windows' Chinese (Simplified) text recognition (OCR) to read the game, and it is not installed " +
             "on this PC.`n`nIt is installed now from Windows Update (about 30 MB). Windows will ask for administrator permission " +
             "and a small window shows the progress.`n`nInstall it now?  (Starfire cannot go on without it.)"
        $r = [System.Windows.Forms.MessageBox]::Show($q, 'Starfire - Chinese text recognition required', 'OKCancel', 'Warning')
        if ([string]$r -ne 'OK') { return $false }
        if (Install-Ocr) { return $true }
        $r2 = [System.Windows.Forms.MessageBox]::Show("The Chinese text recognition is still not available.`n`nIf it was just installed or removed, restart the PC once - Windows sometimes finishes this only after a restart.`nYou can also add it by hand: Settings > Time & language > Language > Chinese (Simplified) > Language options > Optical character recognition.`n`nTry again?", 'Starfire', 'RetryCancel', 'Error')
        if ([string]$r2 -ne 'Retry') { return $false }
    }
}
if (-not (Ensure-Ocr)) { exit 1 }

# ---------- background ----------
function New-SpaceArt([int]$w, [int]$h, $cards) {
    $bmp = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    # deep space: near-black violet to dark wine
    $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush (New-Object System.Drawing.Point(0, 0)), (New-Object System.Drawing.Point($w, $h)), ([System.Drawing.Color]::FromArgb(10, 6, 22)), ([System.Drawing.Color]::FromArgb(26, 4, 14))
    $g.FillRectangle($bg, 0, 0, $w, $h)
    $rnd = New-Object System.Random 7
    # nebula clouds: soft red and purple blobs
    $clouds = @(@(0.78, 0.22, 330, 170, 40, 120), @(0.62, 0.40, 260, 120, 30, 160), @(0.90, 0.55, 220, 150, 20, 140), @(0.15, 0.85, 260, 70, 30, 120), @(0.35, 0.10, 200, 110, 30, 150))
    foreach ($c in $clouds) {
        $cx = $c[0] * $w; $cy = $c[1] * $h; $rr = [double]$c[2]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($cx - $rr), [single]($cy - $rr * 0.7), [single]($rr * 2), [single]($rr * 1.4))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$c[4], [int]$c[3], 20, [int]$c[5])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 10, 0, 20))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    # stars
    for ($i = 0; $i -lt 420; $i++) {
        $x = $rnd.NextDouble() * $w; $y = $rnd.NextDouble() * $h
        $a = 60 + $rnd.Next(195); $sz = 0.6 + $rnd.NextDouble() * 1.6
        $tint = $rnd.Next(3)
        if ($tint -eq 0) { $col = [System.Drawing.Color]::FromArgb($a, 255, 255, 255) } elseif ($tint -eq 1) { $col = [System.Drawing.Color]::FromArgb($a, 255, 200, 220) } else { $col = [System.Drawing.Color]::FromArgb($a, 210, 190, 255) }
        $sb = New-Object System.Drawing.SolidBrush $col
        $g.FillEllipse($sb, [single]$x, [single]$y, [single]$sz, [single]$sz); $sb.Dispose()
    }
    # the supernova: rays, layered glow, white-hot core
    $nx = $w * 0.80; $ny = $h * 0.24
    for ($k = 0; $k -lt 14; $k++) {
        $ang = $k * [Math]::PI / 7 + 0.2; $len = 90 + $rnd.Next(150)
        $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(60, 255, 120, 170)), 1.6
        $g.DrawLine($pen, [single]$nx, [single]$ny, [single]($nx + [Math]::Cos($ang) * $len), [single]($ny + [Math]::Sin($ang) * $len)); $pen.Dispose()
    }
    foreach ($ring in @(@(150, 70, 150, 40, 200), @(95, 120, 230, 40, 120), @(55, 190, 255, 80, 90), @(26, 255, 255, 200, 230))) {
        $rr = [double]$ring[0]
        $path = New-Object System.Drawing.Drawing2D.GraphicsPath
        $path.AddEllipse([single]($nx - $rr), [single]($ny - $rr), [single]($rr * 2), [single]($rr * 2))
        $pb = New-Object System.Drawing.Drawing2D.PathGradientBrush $path
        $pb.CenterColor = [System.Drawing.Color]::FromArgb([int]$ring[1], [int]$ring[2], [int]$ring[3], [int]$ring[4])
        $pb.SurroundColors = @([System.Drawing.Color]::FromArgb(0, 120, 20, 160))
        $g.FillPath($pb, $path); $pb.Dispose(); $path.Dispose()
    }
    $core = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 250, 245))
    $g.FillEllipse($core, [single]($nx - 5), [single]($ny - 5), 10, 10); $core.Dispose()
    # glass cards behind the content
    function Fill-Card($gr, [int]$x, [int]$y, [int]$cw, [int]$ch) {
        $p = New-Object System.Drawing.Drawing2D.GraphicsPath; $rad = 14
        $p.AddArc($x, $y, $rad, $rad, 180, 90); $p.AddArc($x + $cw - $rad, $y, $rad, $rad, 270, 90)
        $p.AddArc($x + $cw - $rad, $y + $ch - $rad, $rad, $rad, 0, 90); $p.AddArc($x, $y + $ch - $rad, $rad, $rad, 90, 90); $p.CloseFigure()
        $fb = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(150, 12, 8, 24))
        $gr.FillPath($fb, $p); $fb.Dispose()
        $pn = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(90, 200, 90, 220)), 1
        $gr.DrawPath($pn, $p); $pn.Dispose(); $p.Dispose()
    }
    foreach ($cd in $cards) { Fill-Card $g ([int]$cd[0]) ([int]$cd[1]) ([int]$cd[2]) ([int]$cd[3]) }
    $g.Dispose()
    return $bmp
}

$W = 720; $H = 600
$cards = @(@(24, 112, 672, 112), @(24, 236, 672, 92), @(24, 340, 672, 92), @(24, 444, 672, 64))

# ---------- window ----------
$f = New-Object System.Windows.Forms.Form
$f.Text = "Starfire $HubVersion"
$f.ClientSize = New-Object System.Drawing.Size($W, $H)
$f.FormBorderStyle = 'FixedSingle'; $f.MaximizeBox = $false
$f.StartPosition = 'CenterScreen'
$f.BackColor = [System.Drawing.Color]::FromArgb(10, 6, 22); $f.ForeColor = [System.Drawing.Color]::White
$f.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
try { $f.Icon = New-Object System.Drawing.Icon (Join-Path $src 'starfire.ico') } catch {}
try { $f.BackgroundImage = New-SpaceArt $W $H $cards; $f.BackgroundImageLayout = 'None' } catch {}
try { $f.GetType().GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($f, $true, $null) } catch {}

$cWhite = [System.Drawing.Color]::FromArgb(245, 240, 255)
$cSoft  = [System.Drawing.Color]::FromArgb(196, 182, 222)
$cRed   = [System.Drawing.Color]::FromArgb(255, 92, 120)
$cGreen = [System.Drawing.Color]::FromArgb(120, 230, 170)
function New-Label([string]$t, [int]$x, [int]$y, [single]$size, [string]$style, [System.Drawing.Color]$col, [int]$w = 0) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $t; $l.BackColor = [System.Drawing.Color]::Transparent; $l.ForeColor = $col
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $size, [System.Drawing.FontStyle]$style)
    $l.Location = New-Object System.Drawing.Point($x, $y)
    if ($w -gt 0) { $l.Size = New-Object System.Drawing.Size($w, [int]($size * 2.2)); $l.AutoEllipsis = $true } else { $l.AutoSize = $true }
    $f.Controls.Add($l); return $l
}
function New-Btn([string]$t, [int]$x, [int]$y, [int]$w, [int]$h, [System.Drawing.Color]$bc, [System.Drawing.Color]$fc, [single]$fs = 9.5) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, $h)
    $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.BackColor = $bc; $b.ForeColor = $fc
    $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', $fs); $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $f.Controls.Add($b); return $b
}
function New-Check([string]$t, [int]$x, [int]$y, [bool]$on) {
    $c = New-Object System.Windows.Forms.CheckBox
    $c.Text = $t; $c.Checked = $on; $c.AutoSize = $true; $c.BackColor = [System.Drawing.Color]::Transparent; $c.ForeColor = $cWhite
    $c.Location = New-Object System.Drawing.Point($x, $y); $f.Controls.Add($c); return $c
}
$cCrimson = [System.Drawing.Color]::FromArgb(214, 40, 90)
$cPurple  = [System.Drawing.Color]::FromArgb(110, 50, 170)
$cDark    = [System.Drawing.Color]::FromArgb(40, 30, 64)

$null = New-Label 'STARFIRE' 26 16 30 'Bold' $cWhite
$null = New-Label "The Hidden Ones companion   |   v$HubVersion" 30 72 9.5 'Regular' $cSoft
$lblOcr = New-Label '' 330 76 8.5 'Bold' $cGreen 360

# --- Starfire Lite card ---
$null = New-Label 'STARFIRE LITE  -  TRANSLATION OVERLAY' 44 122 8.5 'Bold' $cRed
$prev = ''
try { if (Test-Path $verFile) { $prev = ([System.IO.File]::ReadAllText($verFile)).Trim() } } catch {}
if (-not $prev -and (Test-Path (Join-Path $appDir 'StarfireLite.ps1'))) { $prev = 'older' }
function Get-LiteState {
    if ($prev -eq '') { return "Not installed - version $LiteVersion is included and installs with one click" }
    if ($prev -eq $LiteVersion) { return "Version $LiteVersion installed - up to date" }
    return "Installed: $prev  ->  update to $LiteVersion included"
}
$lblLite = New-Label (Get-LiteState) 44 142 11 'Bold' $cWhite 470
$lblLiteRun = New-Label '' 44 170 9 'Regular' $cSoft 470
$btnLiteInst  = New-Btn 'INSTALL / UPDATE' 530 136 150 30 $cPurple $cWhite
$btnLiteStart = New-Btn 'START LITE' 530 172 150 30 $cCrimson $cWhite
$cbShort = New-Check 'Desktop shortcut for Starfire Lite' 44 194 $false

# --- game card ---
$null = New-Label 'THE HIDDEN ONES  -  GAME / LAUNCHER (.EXE)' 44 246 8.5 'Bold' $cRed
$tbGame = New-Object System.Windows.Forms.TextBox
$tbGame.Location = New-Object System.Drawing.Point(44, 268); $tbGame.Size = New-Object System.Drawing.Size(370, 26)
$tbGame.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $tbGame.ForeColor = $cWhite; $tbGame.BorderStyle = 'FixedSingle'
$tbGame.Text = [string]$cfg.gamePath; $f.Controls.Add($tbGame)
$btnGameBrowse = New-Btn 'BROWSE' 422 266 96 28 $cDark $cSoft
$btnGame       = New-Btn 'LAUNCH GAME' 530 266 150 28 $cCrimson $cWhite
$lblGame = New-Label '' 44 298 9 'Regular' $cSoft 630

# --- UU card ---
$null = New-Label 'UU BOOSTER  -  VPN / ACCELERATOR (.EXE)' 44 350 8.5 'Bold' $cRed
$tbUU = New-Object System.Windows.Forms.TextBox
$tbUU.Location = New-Object System.Drawing.Point(44, 372); $tbUU.Size = New-Object System.Drawing.Size(370, 26)
$tbUU.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $tbUU.ForeColor = $cWhite; $tbUU.BorderStyle = 'FixedSingle'
$tbUU.Text = [string]$cfg.uuPath; $f.Controls.Add($tbUU)
$btnUUBrowse = New-Btn 'BROWSE' 422 370 96 28 $cDark $cSoft
$btnUU       = New-Btn 'OPEN UU' 530 370 150 28 $cCrimson $cWhite
$lblUU = New-Label '' 44 402 9 'Regular' $cSoft 630

# --- launch all card ---
$null = New-Label 'LAUNCH ALL - order: UU Booster, wait, game, Starfire Lite' 44 452 8.5 'Bold' $cRed
$cbUU    = New-Check 'UU Booster' 44 474 ([bool]$cfg.startUU)
$cbGame  = New-Check 'Game' 150 474 ([bool]$cfg.startGame)
$cbLite  = New-Check 'Starfire Lite' 230 474 ([bool]$cfg.startLite)
$null = New-Label 'wait after UU (s):' 352 476 9 'Regular' $cSoft
$nudDelay = New-Object System.Windows.Forms.NumericUpDown
$nudDelay.Location = New-Object System.Drawing.Point(468, 472); $nudDelay.Size = New-Object System.Drawing.Size(50, 24)
$nudDelay.Minimum = 0; $nudDelay.Maximum = 120; $nudDelay.Value = [Math]::Max(0, [Math]::Min(120, [int]$cfg.uuDelay))
$nudDelay.BackColor = [System.Drawing.Color]::FromArgb(22, 16, 40); $nudDelay.ForeColor = $cWhite
$f.Controls.Add($nudDelay)

$btnAll   = New-Btn 'LAUNCH ALL' 24 528 420 52 $cCrimson $cWhite 14
$btnShort = New-Btn ('DESKTOP' + [Environment]::NewLine + 'SHORTCUT') 454 528 132 52 $cPurple $cWhite 9.5
$btnClose = New-Btn 'CLOSE' 596 528 100 52 $cDark $cSoft 11
$stat = New-Label 'Ready.' 26 584 8.5 'Regular' $cSoft 670

# ---------- live updates from GitHub (github.com/jett-black/Starfire, latest release) ----------
$UpdRepo = 'jett-black/Starfire'
$lblUpd = New-Label 'Checking for updates ...' 430 22 9 'Regular' $cSoft 266
$btnUpd = New-Btn 'UPDATE' 430 44 120 28 $cCrimson $cWhite
$btnUpd.Visible = $false
$btnChk = New-Btn 'CHECK AGAIN' 560 44 136 28 $cDark $cSoft 8.5
$script:Upd = $null; $script:UpdTask = $null; $script:UpdDl = $null
try { Add-Type -AssemblyName System.Net.Http } catch {}
try { [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12 } catch {}
$script:UpdHttp = New-Object System.Net.Http.HttpClient
$script:UpdHttp.Timeout = [TimeSpan]::FromSeconds(60)
try { $script:UpdHttp.DefaultRequestHeaders.Add('User-Agent', 'Starfire-Updater') } catch {}
try { $script:UpdHttp.DefaultRequestHeaders.Add('Accept', 'application/vnd.github+json') } catch {}
function Get-VerObj([string]$v) { try { return [version](($v -replace '^[^\d]*', '') -replace '[^\d\.].*$', '') } catch { return $null } }
function Start-UpdCheck {
    $lblUpd.Text = 'Checking for updates ...'; $lblUpd.ForeColor = $cSoft; $btnUpd.Visible = $false
    # updates are published as updates/latest.json + the zip in the repo (raw files, no login needed)
    $bust = [DateTime]::UtcNow.Ticks
    try { $script:UpdTask = $script:UpdHttp.GetStringAsync("https://raw.githubusercontent.com/$UpdRepo/main/updates/latest.json?t=$bust") } catch { $lblUpd.Text = 'Update check failed.' }
}
$updTimer = New-Object System.Windows.Forms.Timer
$updTimer.Interval = 250
$updTimer.Add_Tick({
    # 1) the release check came back
    if ($script:UpdTask -and $script:UpdTask.IsCompleted) {
        $t = $script:UpdTask; $script:UpdTask = $null
        if ($t.Status -ne 'RanToCompletion') {
            $m = ''; try { $m = [string]$t.Exception.InnerException.Message } catch {}
            if ($m -match '404') { $lblUpd.Text = "v$HubVersion - no releases published yet" } else { $lblUpd.Text = "v$HubVersion - update check failed (offline?)" }
            return
        }
        try {
            $man = $t.Result | ConvertFrom-Json
            $vNew = Get-VerObj ([string]$man.version); $vCur = Get-VerObj $HubVersion
            $fileN = [string]$man.file
            if ($fileN -and $fileN -match '^[A-Za-z0-9._\-]+\.zip$' -and $vNew -and $vCur -and $vNew -gt $vCur) {
                $script:Upd = [pscustomobject]@{ ver = $vNew.ToString(); url = "https://raw.githubusercontent.com/$UpdRepo/main/updates/$fileN"; notes = [string]$man.notes; size = [int64]$man.size }
                $lblUpd.Text = "Update available:  v$HubVersion  ->  v$($script:Upd.ver)"; $lblUpd.ForeColor = $cGreen
                $btnUpd.Text = "UPDATE TO $($script:Upd.ver)"; $btnUpd.Visible = $true
            } else { $lblUpd.Text = "v$HubVersion - up to date"; $lblUpd.ForeColor = $cGreen }
        } catch { $lblUpd.Text = "v$HubVersion - update check failed" }
    }
    # 2) the download came back: unpack, check, swap the files, restart
    if ($script:UpdDl -and $script:UpdDl.IsCompleted) {
        $t = $script:UpdDl; $script:UpdDl = $null
        if ($t.Status -ne 'RanToCompletion') { Say 'Download failed - nothing was changed. Try again later.'; $btnUpd.Enabled = $true; return }
        try { Apply-Update ([byte[]]$t.Result) } catch { Say ('Update failed - nothing was changed: ' + $_.Exception.Message); $btnUpd.Enabled = $true }
    }
})
$updTimer.Start()
function Apply-Update([byte[]]$data) {
    if ($data.Length -lt 100000 -or ($script:Upd.size -gt 0 -and $data.Length -ne $script:Upd.size)) { throw 'the download is incomplete' }
    $work = Join-Path $env:TEMP ('Starfire-Update-' + [DateTime]::Now.Ticks)
    $zip = $work + '.zip'
    [System.IO.File]::WriteAllBytes($zip, $data)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $work)
    $newExe = Get-ChildItem $work -Recurse -Filter 'Starfire.exe' | Select-Object -First 1
    if (-not $newExe) { throw 'the update does not contain Starfire.exe' }
    $from = $newExe.DirectoryName
    $to = ''
    if ($ExePath -and (Test-Path $ExePath)) { $to = Split-Path $ExePath -Parent }
    if (-not $to) { $to = Join-Path $env:LOCALAPPDATA 'Starfire\program' }
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    # back up the current files first, then copy the new ones over them
    $bak = Join-Path $env:LOCALAPPDATA ('Starfire\backup-' + $HubVersion)
    New-Item -ItemType Directory -Force -Path $bak | Out-Null
    foreach ($fi in Get-ChildItem $from -File) {
        $d = Join-Path $to $fi.Name
        if (Test-Path $d) { Copy-Item $d (Join-Path $bak $fi.Name) -Force; try { (Get-Item $d).IsReadOnly = $false } catch {} }
        Copy-Item $fi.FullName $d -Force
    }
    try { Remove-Item $zip -Force; Remove-Item $work -Recurse -Force } catch {}
    Say "Updated to v$($script:Upd.ver) - restarting Starfire ..."
    Start-Process -FilePath (Join-Path $to 'Starfire.exe') -WorkingDirectory $to
    $f.Close()
}
$btnUpd.Add_Click({
    if (-not $script:Upd) { return }
    $n = $script:Upd.notes; if ($n.Length -gt 900) { $n = $n.Substring(0, 900) + ' ...' }
    $q = "Update Starfire from v$HubVersion to v$($script:Upd.ver)?`n`n$n`n`nStarfire downloads the new version, replaces its files (a backup is kept) and restarts."
    if ([string]([System.Windows.Forms.MessageBox]::Show($q, 'Starfire update', 'OKCancel', 'Information')) -ne 'OK') { return }
    $btnUpd.Enabled = $false
    Say "Downloading v$($script:Upd.ver) ..."
    try { $script:UpdDl = $script:UpdHttp.GetByteArrayAsync($script:Upd.url) } catch { Say ('Download failed: ' + $_.Exception.Message); $btnUpd.Enabled = $true }
})
$btnChk.Add_Click({ Start-UpdCheck })

# desktop shortcut for Starfire itself (points at this Starfire.exe, so it keeps working after live updates)
$deskLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Starfire.lnk'
function Show-ShortState { if (Test-Path $deskLnk) { $btnShort.Text = 'SHORTCUT' + [Environment]::NewLine + 'ON DESKTOP' } }
$btnShort.Add_Click({
    if (-not $ExePath -or -not (Test-Path $ExePath)) { Say 'Start Starfire with Starfire.exe to create its shortcut.'; return }
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($deskLnk)
        $sc.TargetPath = $ExePath
        $sc.WorkingDirectory = (Split-Path $ExePath -Parent)
        $sc.IconLocation = $ExePath + ',0'
        $sc.Description = 'Starfire - The Hidden Ones companion (translator, game, UU Booster)'
        $sc.Save()
        Say 'Desktop shortcut "Starfire" created.'
        Show-ShortState
    } catch { Say ('Shortcut failed: ' + $_.Exception.Message) }
})

$f.AcceptButton = $btnAll
$btnClose.Add_Click({ $f.Close() })

function Show-Ocr([bool]$ok) {
    if ($ok) { $lblOcr.Text = 'Chinese text recognition (OCR): installed'; $lblOcr.ForeColor = $cGreen }
    else { $lblOcr.Text = 'Chinese text recognition (OCR): MISSING'; $lblOcr.ForeColor = $cRed }
}
function Gate {
    # every button calls this first: re-checks the OCR, offers to install it, and stops the action without it
    $ok = Ensure-Ocr
    Show-Ocr $ok
    if (-not $ok) { Say 'Not started: Chinese text recognition (OCR) is required.' }
    return $ok
}
function Say([string]$t) { $stat.Text = $t; [System.Windows.Forms.Application]::DoEvents() }
function Show-PathState {
    if ($tbGame.Text -and (Test-Path $tbGame.Text)) { $lblGame.Text = 'Found.'; $lblGame.ForeColor = $cGreen } elseif ($tbGame.Text) { $lblGame.Text = 'This file does not exist - use BROWSE.'; $lblGame.ForeColor = $cRed } else { $lblGame.Text = 'Pick the game or its launcher (for example YiRenZhiXia.exe) with BROWSE.'; $lblGame.ForeColor = $cSoft }
    if ($tbUU.Text -and (Test-Path $tbUU.Text)) { $lblUU.Text = 'Found.'; $lblUU.ForeColor = $cGreen } elseif ($tbUU.Text) { $lblUU.Text = 'This file does not exist - use BROWSE.'; $lblUU.ForeColor = $cRed } else { $lblUU.Text = 'Pick UU Booster (uu.exe or its shortcut target) with BROWSE.'; $lblUU.ForeColor = $cSoft }
    if ((Get-LiteProcs).Count -gt 0) { $lblLiteRun.Text = 'Starfire Lite is running now (F8 = overlay on / off).' } else { $lblLiteRun.Text = 'Starfire Lite is not running.' }
}
function Save-Now {
    $cfg.gamePath = $tbGame.Text.Trim('" '); $cfg.uuPath = $tbUU.Text.Trim('" '); $cfg.uuDelay = [int]$nudDelay.Value
    $cfg.startUU = $cbUU.Checked; $cfg.startGame = $cbGame.Checked; $cfg.startLite = $cbLite.Checked
    Save-Cfg
}
function Pick-Exe($tb, [string]$title) {
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.Title = $title; $d.Filter = 'Programs (*.exe;*.lnk)|*.exe;*.lnk|All files (*.*)|*.*'
    if ($tb.Text -and (Test-Path (Split-Path $tb.Text -Parent -ErrorAction SilentlyContinue))) { $d.InitialDirectory = Split-Path $tb.Text -Parent }
    if ($d.ShowDialog($f) -eq 'OK') {
        $p = $d.FileName
        if ($p -like '*.lnk') { try { $p = (New-Object -ComObject WScript.Shell).CreateShortcut($p).TargetPath } catch {} }
        $tb.Text = $p; Save-Now; Show-PathState
    }
}
function Start-Exe([string]$path, [string]$name) {
    $path = $path.Trim('" ')
    if (-not $path -or -not (Test-Path $path)) { Say "$name : no valid .exe chosen - use BROWSE."; return $false }
    try { Start-Process -FilePath $path -WorkingDirectory (Split-Path $path -Parent); Say "$name started."; return $true }
    catch { Say "$name could not be started: $($_.Exception.Message)"; return $false }
}

# ---------- Starfire Lite install / start ----------
function New-LiteShortcut {
    $ws = New-Object -ComObject WScript.Shell
    $sc = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Starfire Lite.lnk'))
    $sc.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $sc.Arguments = '-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $appDir 'StarfireLite.ps1') + '"'
    $sc.WorkingDirectory = $appDir; $sc.IconLocation = (Join-Path $appDir 'starfire.ico') + ',0'; $sc.WindowStyle = 7
    $sc.Save()
}
function Install-Lite {
    Say 'Installing Starfire Lite ...'
    $procs = Get-LiteProcs
    foreach ($p in $procs) { try { Stop-Process -Id $p.ProcessId -Force } catch {} }
    if ($procs.Count -gt 0) { Start-Sleep -Milliseconds 800 }
    New-Item -ItemType Directory -Force -Path $appDir | Out-Null
    foreach ($fn in $liteFiles) {
        $s = Join-Path $src $fn
        if (Test-Path $s) { $d = Join-Path $appDir $fn; if (Test-Path $d) { try { (Get-Item $d).IsReadOnly = $false } catch {} }; Copy-Item $s $d -Force }
    }
    [System.IO.File]::WriteAllText($verFile, $LiteVersion)
    if ($cbShort.Checked) { try { New-LiteShortcut } catch {} }
    $script:prev = $LiteVersion; $lblLite.Text = Get-LiteState
    Say "Starfire Lite $LiteVersion installed."
    return ($procs.Count -gt 0)
}
function Start-Lite {
    if ($script:prev -ne $LiteVersion) { $null = Install-Lite }
    if ((Get-LiteProcs).Count -gt 0) { Say 'Starfire Lite is already running - F8 turns the overlay on / off.'; return }
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $appDir 'StarfireLite.ps1')`"")
    Say 'Starfire Lite started - look for its icon in the tray. F8 turns the overlay on / off.'
}

$btnLiteInst.Add_Click({ if (-not (Gate)) { return }; try { $wasRunning = Install-Lite; if ($wasRunning) { Start-Lite } } catch { Say ('Install failed: ' + $_.Exception.Message) }; Show-PathState })
$btnLiteStart.Add_Click({ if (-not (Gate)) { return }; try { Start-Lite } catch { Say ('Start failed: ' + $_.Exception.Message) }; Show-PathState })
$btnGameBrowse.Add_Click({ Pick-Exe $tbGame 'Choose The Hidden Ones (game or launcher .exe)' })
$btnUUBrowse.Add_Click({ Pick-Exe $tbUU 'Choose UU Booster (.exe)' })
$btnGame.Add_Click({ if (-not (Gate)) { return }; Save-Now; $null = Start-Exe $tbGame.Text 'The Hidden Ones' })
$btnUU.Add_Click({ if (-not (Gate)) { return }; Save-Now; $null = Start-Exe $tbUU.Text 'UU Booster' })
$tbGame.Add_Leave({ Save-Now; Show-PathState })
$tbUU.Add_Leave({ Save-Now; Show-PathState })

$btnAll.Add_Click({
    if (-not (Gate)) { return }
    Save-Now
    $btnAll.Enabled = $false
    try {
        if ($cbUU.Checked) {
            if (Start-Exe $tbUU.Text 'UU Booster') {
                $wait = [int]$nudDelay.Value
                for ($s = $wait; $s -gt 0; $s--) { Say "UU Booster started - starting the game in $s s (connect / accelerate the game in UU now) ..."; for ($k = 0; $k -lt 10; $k++) { Start-Sleep -Milliseconds 100; [System.Windows.Forms.Application]::DoEvents() } }
            }
        }
        if ($cbGame.Checked) { $null = Start-Exe $tbGame.Text 'The Hidden Ones' }
        if ($cbLite.Checked) { Start-Lite }
        Say 'Launched. Have fun!'
    } catch { Say ('Launch failed: ' + $_.Exception.Message) }
    $btnAll.Enabled = $true
    Show-PathState
})
$f.Add_FormClosing({ Save-Now })
$f.Add_Shown({ Show-ShortState; Start-UpdCheck; Show-Ocr (Test-ChineseOcr); Show-PathState; $f.TopMost = $true; $f.Activate(); $f.TopMost = $false })
[void]$f.ShowDialog()
